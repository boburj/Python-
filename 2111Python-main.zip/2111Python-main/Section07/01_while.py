i = 0
while i < 5:
    print(f'Hello World - {i}')
    i+=1