n = int(input('정수를 입력하세요 >>>'))
i=0
if n > 0:
    while i < n:
        i+=1
        print(f"{i}번째 Hello")
else:
    print('잘못된 입력입니다.')

