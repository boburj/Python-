for i in range(5): #range(n) 0~n-1까지 숫자를 하나씩 뽑음
    print(i)
print('------------')

for i in range(1,10):#1부터 10전까지 숫자를 하나씩 뽑음, 1씩 증가
    print(i)
print('------------')
#range(시작값,반복문 종료값,증감값)
for i in range(1,10,2):#1부터 10전까지 숫자를 하나씩 뽑음 2씩 증가
    print(i)
print('------------')

