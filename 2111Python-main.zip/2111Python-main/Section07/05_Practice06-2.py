i=1
while i <= 100:
    if i % 7 == 0:
        print(i)
    i+=1