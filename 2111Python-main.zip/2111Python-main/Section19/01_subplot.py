import matplotlib.pyplot as plt
fiqure = plt.figure()
#1행 2열  1번째 차트
axes1 = fiqure.add_subplot(1,2,1)
#1행 2열  2번째 차트
axes2 = fiqure.add_subplot(1,2,2)
#2행 2열  1번째 차트
axes3 = fiqure.add_subplot(2,2,1)
#2행 2열  2번째 차트
axes4 = fiqure.add_subplot(2,2,2)


plt.show()
