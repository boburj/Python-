
count = 2
if count % 2 == 0:
    pass #임시로 실행영역을 잡아줌
print('프로그램 종료')