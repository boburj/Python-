for i in range(1,101):
    if i % 2 == 0:
        continue#남은 반복문 코드를 무시하고 바로 다음 반복으로 넘어감
    print(i)