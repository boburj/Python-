print('Hello')
print('World')
print(10)
print(10 + 20)