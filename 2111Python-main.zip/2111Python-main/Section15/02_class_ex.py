class Person:
    pass

#클래스명() ---> 생성자로 객체하나를 생성
person1 = Person()
person2 = Person()
person3 = Person()
person4 = Person()

print(person1)
print(person2)
print(person3)
print(person4)

