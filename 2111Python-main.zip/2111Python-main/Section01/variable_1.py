box = 10
print(box)
box = 20
box = 30
print(box)
t = 200
print(t)
print(box + t)
result = box - t
box = 100
print(result)
'''
    변수명 규칙
        1. 알파벳, 숫자, _
        2. 대소문자 구분
        3. 변수명은 중복 X
        4. 변수명 첫글자는 숫자 X
        5. 키워드와 동일하면 안됨        
'''