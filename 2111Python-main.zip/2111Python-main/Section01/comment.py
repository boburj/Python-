'''
    여러줄 주석
    해당 소스코드에대한 설명
    주석은 실행되지 않는 코드
'''
#한줄 주석
print('Hello1')
print('Hello2')
#print('Hello3')
#print('Hello4')
#print('Hello5')
print('Hello6')