num = int(input("10~99사이의 정수를 입력하세요>>>"))
print(f'십의 자리 : {num // 10}')
print(f'일의 자리 : {num % 10}')