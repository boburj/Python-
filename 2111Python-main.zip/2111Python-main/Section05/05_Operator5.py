#비트 연산자  & | ^ ~ >> <<
n1, n2 = 10, 7
print(n1 & n2) #and
print(n1 | n2) #or
print(n1 ^ n2) #xor
print(~n1) #not
n3 = 1
print(n3 << 3)
n4 = 256
print(n4 >> 1)
print(n4 >> 2)
n5 = -11
print(n5 >> 1) #부호비트를 제외하고 전체 비트 이동
