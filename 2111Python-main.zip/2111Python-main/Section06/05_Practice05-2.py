no = int(input('정수를 입력하세요>>>'))
if no % 3 == 0:
    print(f'{no}는 3의 배수입니다.')
else:
    print(f'{no}는 3의 배수가 아닙니다.')
