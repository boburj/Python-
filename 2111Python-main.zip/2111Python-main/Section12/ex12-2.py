import math
#원주율
print(math.pi)
#소수점 내림
print(math.floor(1.1))
#소수점 올림
print(math.ceil(1.1))
#소수점 절삭
print(math.trunc(-1.9))
#제곱근
print(math.sqrt(25))
#거듭제곱
print(math.pow(2,10)) #2의 10승