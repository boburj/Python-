#type 현재 변수나 값이 어떤 데이터 타입인지 알려주는 함수
num = 10
pi = 3.1415
flag = True
name = "홍길동"
list1 = []
print(type(num))
print(type(3))
print(type(pi))
print(type(flag))
print(type(name))
print(type(list1))