a = float(input('첫 번째 실수를 입력하세요 >>> '))
b = float(input('두 번째 실수를 입력하세요 >>> '))

print(f'{a}와 {b}의 합은 {a + b}입니다.')
