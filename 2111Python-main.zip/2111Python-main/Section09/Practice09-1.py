lst = ['red','orange','yellow','green','blue','navy','puple']
for idx, item in enumerate(lst):
    print(f'무지개의 {idx+1}의 색은 {item}입니다.')