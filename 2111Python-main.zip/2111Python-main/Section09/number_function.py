#절대값 구하는 함수
print(abs(10),abs(-10))
#몫과 나머지 구하는 함수 - 결과는 튜플
print(divmod(10,7))
#문자열을 정수로 바꾸는 함수
print(int('100') * 2)
#문자열을 실수로 바꾸는 함수
print(float('3.1415') * 2)
#최대값 구하는 함수
lst = [123,15,2,15,56,21,6]
print(max(lst),max(2,1,5,3,4,6,7))
#최소값 구하는 함수
print(min(lst),min(2,1,5,3,4,6,7))
#거듭제곱
print(pow(2,10)) #2의 10승
print(pow(2,-2)) #2의 -2승
#반올림
print(round(156.12345,0))
print(round(156.12345,1))
print(round(156.12345,2))
print(round(156.12345,3))
print(round(156.12345,4))
print(round(156.12345,-1))
print(round(156.12345,-2))
#총합 함수
list1 = [123,53,1,514,12,5341]
list2 = ['H','e','l','l','o']
print(sum(list1))
#숫자 이외의 값은 sum 연산이 X 에러 처리
#print(sum(list2))






